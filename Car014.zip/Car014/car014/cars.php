C:/xampp/htdocs/Car014/
├── config/
│   └── db.php
├── api/
│   └── car014/
│       └── cars/
│           └── car.php
├── css/
│   └── style.css
├── cars.php
├── login.php
└── ... 