<?php
include_once 'C:/xampp/htdocs/050_Carrent/config/db.php';
